#!/bin/sh -e

cask exec ecukes "$@"
