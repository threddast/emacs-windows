===================
 Flycheck licenses
===================

.. _flycheck-gpl:

GNU General Public License 3
============================

.. literalinclude:: ../COPYING

.. _flycheck-cc-by-sa:

Creative Commons Attribution-ShareAlike 4.0 International
=========================================================

.. literalinclude:: COPYING.cc-by-sa
