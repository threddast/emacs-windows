I, the contributor, agree to licence my contributions to the Flycheck project
under the terms of the [GPL 3.0][1] and any later version, and to license my
contributions to the documentation of the Flycheck project under the terms of
the [Creative Commons Attribution-ShareAlike 4.0 International][2] license.

[1]: http://www.flycheck.org/en/latest/licenses.html#flycheck-gpl
[2]: http://www.flycheck.org/en/latest/licenses.html#flycheck-cc-by-sa
