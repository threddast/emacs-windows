/** A bad if */

if ( /* nothing here */ ) // comment
