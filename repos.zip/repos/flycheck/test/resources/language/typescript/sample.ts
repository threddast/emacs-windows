import * as mocha from 'mocha';
import * as chai from 'chai';

function invalidAlignment() {
  var a:string = "test string";
  alert('Hi!')
}
