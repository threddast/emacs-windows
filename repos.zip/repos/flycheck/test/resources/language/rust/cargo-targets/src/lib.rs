mod a;

fn foo_lib() {}

#[test]
fn test() { let foo_lib_test = 0; }
