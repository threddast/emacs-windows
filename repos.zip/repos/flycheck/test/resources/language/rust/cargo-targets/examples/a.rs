fn main() { let foo_ex_a = 0; }

#[test]
fn test() { let foo_ex_a_test = 0; }
