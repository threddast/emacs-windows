fn main() { let unused = 0; }
