// A simple syntax error

fn main() {
    bla;
}
