use super::imported;
pub fn foo() {
    let x = "10";
    println!("hey {}", imported::BAR);
}
