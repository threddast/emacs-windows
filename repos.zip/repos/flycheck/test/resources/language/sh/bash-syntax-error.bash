#!/bin/bash

if true then
    echo "Hello World"
fi
