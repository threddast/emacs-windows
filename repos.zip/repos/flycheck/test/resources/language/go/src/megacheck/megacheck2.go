package main

var xs = []int{1, 2, 3}
