package main

import "fmt"

func main() {
	var x int
	fmt.Println(int(x))
}
