package DependencyA;

use parent Exporter;

@EXPORT = qw($dependency_a);

our $dependency_a = 'foo';

1;
