use strict;

print $dependency_a;
print $dependency_b;

1;
