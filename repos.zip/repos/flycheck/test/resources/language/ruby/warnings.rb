# A bunch of questionable Ruby stuff

class Person
  def initialize(_name)
    arr = [:one, :twoTho, :top_gun]
    puts "test"
  end

  def greet
    if true then
      return "Hello, #{@name}"
    end
  end
end

test == 20
