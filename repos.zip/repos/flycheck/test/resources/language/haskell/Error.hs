module Haskell.Error where

foo :: IO ()
foo = putStrLn True
