# pylint: disable=missing-module-docstring
import sys # This has column 0

"""
This error has column -1
"""
