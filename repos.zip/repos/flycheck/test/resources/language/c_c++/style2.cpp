void f(int x)
{
  int i = 0;
  if (x) {
    for ( ; i < 10; ++i) ;
  }
}
