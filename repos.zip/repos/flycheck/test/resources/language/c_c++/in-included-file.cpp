class test {};

#include "warning.c"
