<!-- Please search the issue tracker before creating one -->

## What happened?

## What did you expect to happen?

## Steps to reproduce
1. ...
2. ...
3. ...

## System Information
+ Emacs version: <!-- e.g. 26.3, 27.1, or 28.0.50 -->
+ Emacs distro: <!-- e.g. Doom Emacs, Spacemacs, None, etc -->
+ Operating system: <!-- e.g. Arch, NixOS, Windows, MacOS, etc -->
+ Installed commit of doom-themes: <!-- e.g. a1b2c3d -->
+ Which theme are you using: <!-- e.g. doom-one -->

